matio = require 'matio'
require 'image'

function dump(mode)
  data = matio.load(mode .. '.mat')
  imgs = data.cache_imgs
  imgs = torch.reshape(imgs, imgs:size()[1], 1, 32, 32)
  labels = data.cache_labels
  --shuffling
  rids = torch.randperm(imgs:size()[1])
  final_imgs = torch.zeros(imgs:size()[1], 1, 32, 32)
  final_labels = torch.zeros(imgs:size()[1])
  for i=1,imgs:size()[1] do
    final_imgs[i] = imgs[rids[i]]
    final_labels[i] = labels[rids[i]]
  end
  torch.save(mode .. '_imgs.t7', final_imgs)
  torch.save(mode .. '_labels.t7', final_labels)
end

dump('omniglot_train')
dump('omniglot_test')
